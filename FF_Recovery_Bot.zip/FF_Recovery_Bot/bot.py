import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler,
    ContextTypes, filters
)

logging.basicConfig(level=logging.INFO)
TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))

SERVICES = {
    "link": "مساعدة ربط الحسابات",
    "middle": "خدمة الوساطة",
    "topup": "طلب شحن",
    "support": "الدعم والمساعدة",
}

def menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔗 مساعدة ربط الحسابات", callback_data="link")],
        [InlineKeyboardButton("🤝 خدمة الوساطة", callback_data="middle")],
        [InlineKeyboardButton("💎 طلب شحن", callback_data="topup")],
        [InlineKeyboardButton("🛠 الدعم والمساعدة", callback_data="support")],
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text(
        "مرحباً بك في FF Recovery Bot\n\nاختر الخدمة التي تحتاجها من القائمة:",
        reply_markup=menu()
    )

async def choose_service(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    service = query.data
    if service not in SERVICES:
        return
    context.user_data["service"] = service
    await query.message.reply_text(
        f"اخترت: {SERVICES[service]}\n\n"
        "اكتب وصف طلبك هنا. لا ترسل كلمة مرور أو رمز تحقق أو مفتاح API أو بيانات دفع سرية."
    )

async def receive_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    service = context.user_data.get("service")
    if not service:
        await update.message.reply_text("ابدأ أولاً بالأمر /start ثم اختر خدمة.")
        return

    user = update.effective_user
    description = update.message.text or "[رسالة غير نصية]"
    if ADMIN_ID:
        username = f"@{user.username}" if user.username else "لا يوجد"
        message = (
            "📩 طلب جديد في FF Recovery Bot\n\n"
            f"الخدمة: {SERVICES[service]}\n"
            f"الاسم: {user.full_name}\n"
            f"المعرف: {username}\n"
            f"Telegram ID: {user.id}\n\n"
            f"تفاصيل الطلب:\n{description}"
        )
        try:
            await context.bot.send_message(chat_id=ADMIN_ID, text=message)
        except Exception:
            logging.exception("Could not notify admin")
            await update.message.reply_text(
                "تعذر إرسال الطلب للمسؤول حالياً. حاول لاحقاً أو استخدم /start."
            )
            return
        await update.message.reply_text("✅ وصل طلبك إلى المسؤول. سيتم التواصل معك عبر تيليجرام.")
    else:
        await update.message.reply_text(
            "البوت لم يُكمل الإعداد بعد: المسؤول لم يضبط ADMIN_ID."
        )
    context.user_data.clear()

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text("تم إلغاء الطلب. استخدم /start لاختيار خدمة أخرى.")

def main():
    if not TOKEN:
        raise RuntimeError("ضع BOT_TOKEN في متغيرات البيئة.")
    if not ADMIN_ID:
        raise RuntimeError("ضع ADMIN_ID في متغيرات البيئة.")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(CallbackQueryHandler(choose_service))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, receive_request))
    app.run_polling()

if __name__ == "__main__":
    main()
